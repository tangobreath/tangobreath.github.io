---
# This file only exists to create a link to an external site in the sidebar.
# You can change it to link to a different site, or delete it to remove the "Documentation" link.
# To create links to social media sites, check out `_data/authors.yml`!
redirect_to: https://hydejack.com/docs/
title: Documentation
menu: true
order: 2
---
