---
# Featured tags need to have the `list` layout.
layout: list

# The title of the tag's page.
title: Example

# The name of the tag, used in a post's front matter (e.g. tags: [<slug>]).
slug: example

# (Optional) Write a short (~150 characters) description of this featured tag.
description: >
  This is a featured category, which have their own page.
  Check out `_featured_tags/example.md` to learn how to create your own.

# Setting `menu` will generate an entry in the sidebar for this tag.
menu: true
order: 1
---
