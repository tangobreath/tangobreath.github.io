---
id: 14458
title: Articles
date: 2012-01-08T20:53:26+00:00
author: Eric Gebhart
layout: page
guid: http://tangobreath.com/?page_id=14458
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1330033928";}'
et_ptemplate_settings:
  - 'a:5:{s:16:"et_fullwidthpage";i:0;s:22:"et_ptemplate_blogstyle";i:1;s:22:"et_ptemplate_showthumb";i:0;s:21:"et_ptemplate_blogcats";a:1:{i:0;i:217;}s:25:"et_ptemplate_blog_perpage";i:10;}'
dcssb_short_url:
  - http://tinyurl.com/blqysjl
sfw_pwd:
  - vXqxhzam2Dw1
sfw_comment_form_password:
  - KLdW1xFQrx5D
---
