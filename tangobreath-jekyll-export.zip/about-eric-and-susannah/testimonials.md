---
id: 95
title: Testimonials
date: 2011-09-17T12:00:23+00:00
author: Susannah
layout: page
guid: http://wordpress/?page_id=95
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328900696";}'
dcssb_short_url:
  - http://tinyurl.com/bpmkr8e
sfw_pwd:
  - WNpoPlKTUPbA
sfw_comment_form_password:
  - 6xMuqtMdKAm2
---
# Here are a few testimonials from things our students have written to us.

* * *

<div>
  I loved the freshness of your style and your way of teaching.
</div>

<div>
  You were both very understanding, friendly, funny and patient, so thank you thank you thank you.
</div>

Ah, there is one negative thing: those 4 hours passed wayyyy too fast 🙂

* * *

Eric and Susannah, your presence and dedication to the tango and to whole body consciousness comes out in your teaching. For that, I am ever grateful. I enjoy learning new things about my body&#8217;s awareness. Most especially, I love that there are things about the dance in relation to my body that haven&#8217;t been able to be translated that now have a way of expression. It&#8217;s all in the way you encourage going deeper into the sensitivity of the whole dance. I love it! Look forward to more discoveries. Blessings!

* * *

Thank you Eric and Susannah, it was a really wonderful intro! I can&#8217;t help but think how amazing it would have been to have something like this available when I first started to dace. Even after several years of dancing and being a reasonably experienced dancer, I found the Tango Immersive very beneficial to me. Thank you.

* * *

Awesome Class today. VERY awesome Teachers!!! I wish it was every week!

* * *

Thank you for such a wonderful class&#8230; we&#8217;re both so invigorated now with what we&#8217;ve learned and looking forward to part II&#8230; Thanks to all for patience and kindness&#8230;

* * *

Thank you, Eric and Susannah for such a delightful class! Together you created a very warm, inviting, safe and fun environment in which to learn.

* * *

&#8220;TangoBreath not only fosters the ability to dance more effectively, but also enables a meditative-type of mental concentration. A friendly and collaborative approach to teaching leads to a positive, unified environment. Much love and thank you both for doing what you do.&#8221;

* * *

&#8220;Eric and Susannah&#8217;s TangoBreath and TangoLab class was really a turning point for me. I&#8217;d been stuck in that stage where nothing quite clicked &#8211; I knew I loved Tango but I just couldn&#8217;t make it work. But getting the right muscle memory from the TangoBreath class, combined with a chance to practice the feel and subtlety of leading and following in TangoLab made all the difference. Suddenly things started to make sense! I can&#8217;t express how valuable this has been and how grateful I am for their kind, patient, thoughtful help.&#8221;

* * *

&#8220;A message, to let you know what a wonderful class (the TangoBreath) we had in Asheville. I am still practising the exercises, and the more I do it, the more I am convinced that what you guys teach is essential!&#8221;

* * *

&#8220;Asheville has a tiny tango community and it&#8217;s been interesting to observe a community slowly taking root. In such a small place, I took one of the absolutely best classes of my life training movement and especially disassociation. These two should be on tour and there should be more classes like theirs on the (beautiful) subtle basics.&#8221;

* * *

&#8220;Eric and Susannah are caring, supportive and thoughtful teachers who do their utmost to make everyone feel comfortable at their own level. In addition, they include enough challenge to keep us all engaged. TangoBreath offers something that regular tango lessons do not- an opportunity to really focus on posture, balance, core strength and flow. My tango improved significantly within the first three sessions. The muscle memory that comes from repeated practice has made my dance more effortless and intuitive, and therefore much more fun!&#8221;

* * *