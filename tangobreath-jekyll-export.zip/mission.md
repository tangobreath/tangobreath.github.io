---
id: 5
title: Mission
date: 2011-09-16T20:57:06+00:00
author: Eric Gebhart
layout: page
guid: http://wordpress/?page_id=5
sfw_comment_form_password:
  - Aws3L7zTzVaF
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328835646";}'
dcssb_short_url:
  - http://tinyurl.com/cu39q96
sfw_pwd:
  - eCA91WgTGKOv
---
## We are dedicated to providing individual and group exploration and practice of Argentine tango technique through body- and breath-conscious movement.

<div>
  Our mission is to create an environment that will nurture and support our students by helping them find awareness and self-knowledge in order to deeply understand Argentine tango movement.
</div>

<div>
</div>

<div>
  <a href="http://tangobreath.com/wp-content/uploads/2011/09/tangobreathtime1.jpg"><img class="alignnone size-full wp-image-144" src="http://tangobreath.com/wp-content/uploads/2011/09/tangobreathtime1.jpg" alt="Tango Breath enabling our mission, A way of learning Argentine tango movement and posture with intention." width="133" height="53" /></a>
</div>

<div>
</div>

## The Practice of Argentine tango movement with intention.

<div>
  <p>
    All too often, tango practice is going through the motions. The goal of TangoBreath is to create an environment where Argentine tango technique and movement can be practiced with full intention.
  </p>
  
  <div>
    By guiding a slow sequence of tango-based movement, we are able to break down and focus on every aspect of each individual movement, from weight changes, to linear movement, to circular, or spiral, movement.  In so doing, we challenge our students to develop body awareness, body memory, strength, and natural, graceful, and powerful movement.
  </div>
</div>

#