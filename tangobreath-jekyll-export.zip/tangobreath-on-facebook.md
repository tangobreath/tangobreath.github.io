---
id: 1821
title: TangoBreath on Facebook
date: 2011-12-22T13:26:47+00:00
author: Eric Gebhart
layout: page
guid: http://tangobreath.com/?page_id=1821
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328878753";}'
dcssb_short_url:
  - http://tinyurl.com/cyfsdj7
sfw_pwd:
  - L847hD4PQgHD
sfw_comment_form_password:
  - KWutMheewwqt
---
We have a facebook page where we make announcements and plug in to the facebook community.  Here are the recent posts.  Like us if you would like to connect through facebook.

We also have a presence on Google+, you can see that feed [here.](http://tangobreath.com/category/googleplus/ "The TangoBreath Googleplus feed.")  Circle us if you like.

You may alternatively wish to subscribe to our calendar [here.](http://tangobreath.com/when-where/ "Our Calendar Page")

[fb_feed]