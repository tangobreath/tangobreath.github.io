---
id: 21932
title: 'Today we’re joining Wikipedia, Twitter, Tumblr, Reddit, Mozilla and other Internet&#8230;'
date: 2012-01-18T12:29:42+00:00
author: Eric Gebhart
layout: post
guid: 'http://tangobreath.com/today-we%e2%80%99re-joining-wikipedia-twitter-tumblr-reddit-mozilla-and-other-internet/'
permalink: '/today-we%e2%80%99re-joining-wikipedia-twitter-tumblr-reddit-mozilla-and-other-internet/'
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328860282";}'
dcssb_short_url:
  - http://tinyurl.com/c438cvp
sfw_pwd:
  - RHBheqtDYTWW
sfw_comment_form_password:
  - dBaADxXGObdh
categories:
  - Google+
tags:
  - Google+
---
**Reshared post from +[Google](https://plus.google.com/116899029375914044550)**

> Today we’re joining Wikipedia, Twitter, Tumblr, Reddit, Mozilla and other Internet companies in speaking out against the PROTECT IP Act (PIPA) and the Stop Online Piracy Act (SOPA). We’re asking you to do the same—read our blog post <http://goo.gl/Cq4nb> and help protect the web by signing the petition:

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <div style='height:120px;width:120px;overflow:hidden;float:left;margin-top:0px;padding-top:0px;margin-right:10px;vertical-align:top;text-align:center;clear:both;'>
    <img style='max-width:none;' src='http://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=https%3A%2F%2Fwww.google.com%2Flanding%2Ftakeaction%2Ftakeaction.png' border='0' />
  </div>
  
  <p>
    <a href='http://goo.gl/YE0GW'>End Piracy, Not Liberty – Google</a><br /> Millions of Americans oppose SOPA and PIPA because these bills would censor the Internet and slow economic growth in the U.S.. Two bills before Congress, known as the Protect IP Act (PIPA) in the Sena&#8230;
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/cNExbTyYgrb' target='_new'>View post on Google+</a>
  </p>