---
id: 73000
title: Imagery can either help us or hinder us
date: 2012-03-08T13:43:35+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/imagery-can-either-help-us-or-hinder-us/
permalink: /imagery-can-either-help-us-or-hinder-us/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1331233268";}'
dcssb_short_url:
  - http://tinyurl.com/c5fjftw
sfw_pwd:
  - v7zJQFXG1fGA
sfw_comment_form_password:
  - 7jFN1tiPi4OT
categories:
  - Google+
tags:
  - Google+
---
We discuss the flow of movement, it's origins and how to keep it flowing. For starters please **don't** "lead from the chest."

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <p>
    <a href='http://tangobreath.com/imagery-and-the-internal-flow-of-movement-in-argentine-tango/'>Imagery and the internal flow of movement in Argentine tango. &#8211; TangoBreath.</a><br /> The basis of Argentine tango is the communication of movement through the embrace. Here is some imagery that may help to realize this subtle concept.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/5DgjdEP6pAH' target='_new'>View post on Google+</a>
  </p>