---
id: 45220
title: A Special Homewood Milonga.
date: 2012-01-01T21:27:16+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/?p=45220
permalink: /a-special-homewood-milonga/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328926342";}'
dcssb_short_url:
  - http://tinyurl.com/bv6otqx
sfw_pwd:
  - VnaOb96KAQ2L
sfw_comment_form_password:
  - 994I8ojp6rgE
image: /wp-content/uploads/2011/12/TangoBreathJan7.003.png
categories:
  - Asheville Events
  - Past Events
tags:
  - argentine tango
  - Asheville
  - Asheville tango
  - milonga
  - tango asheville
  - TangoBreath
---
### We cordially invite you to a special Homewood milonga.

## SATURDAY, JANUARY 7th MILONGA, at Homewood in Asheville, NC.

with **DJ Lisa Jacobs**
  
At [Homewood](http://www.mybelovedhomewood.com/ "The Homewood website."), 19 Zillicoa, Asheville, NC. [Map](http://maps.google.com/maps?q=190+zillicoa,+asheville,+nc&um=1&ie=UTF-8&hq=&hnear=0x88598b4e1cf9b8eb:0x8eefb5e16d5df521,190+Zillicoa+St,+Asheville,+NC+28801&gl=us&ei=k5XbTuHlI42Wtwevwsj2CA&sa=X&oi=geocode_result&ct=title&resnum=1&ved=0CB0Q8gEwAA "Map to Homewood")

Homewood is a 1927, post victorian castle with an amazingly warm atmosphere great seating and an amazing dance floor.
  
Located in the historic Montford neighborhood of Asheville, NC.

We have an amazing sound system, and a wonderful DJ. This homewood milonga is not to be missed.

Susannah will be making a special treat which are always amazing.

8:00 PM &#8211; 1:00 AM
  
$10

Light refreshments and hot mulled cider, coffee, tea and wine will be served.
  
**BYOB**