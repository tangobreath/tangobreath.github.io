---
id: 26685
title: 'Monday, Jan. 23rd.  TangoBreath in RDU'
date: 2012-01-23T14:03:22+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/?p=26685
permalink: /monday-jan-23rd-tangobreath-in-rdu/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328832110";}'
dcssb_short_url:
  - http://tinyurl.com/cduo259
sfw_pwd:
  - wAx2sVZKnACk
sfw_comment_form_password:
  - RDsrWGoXxVye
categories:
  - Announcements
---
We will be teaching TangoBreath for Jae&#8217;s first class at [Triangle Dance Studio](http://triangledancestudio.com/ "Triangle Dance Studio.").

Monday, January 23rd.
  
7:00-8:00.

Come on out and join us!