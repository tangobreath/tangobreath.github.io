---
id: 31504
title: 'This week&#39;s body awareness challenge'
date: 2012-01-28T13:42:54+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/this-weeks-body-awareness-challenge/
permalink: /this-weeks-body-awareness-challenge/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328832110";}'
dcssb_short_url:
  - http://tinyurl.com/d47moz7
sfw_pwd:
  - 3myBafWXoCMp
categories:
  - Google+
tags:
  - Google+
---
We had a great class in the triangle, and we did give a challenge this week, It's been up a couple of days already, but if you haven't seen it, here it is!

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <p>
    <a href='http://tangobreath.com/free-your-hip/'>Free your hip! &#8211; TangoBreath</a><br /> Free your hip, Let it relax and drop, but don't pop the other one.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/2Ba61jMRVHa' target='_new'>View post on Google+</a>
  </p>