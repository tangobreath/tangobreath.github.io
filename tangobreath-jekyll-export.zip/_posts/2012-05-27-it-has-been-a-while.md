---
id: 160870
title: It has been a while
date: 2012-05-27T23:52:42+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/it-has-been-a-while/
permalink: /it-has-been-a-while/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1338177753";}'
dcssb_short_url:
  - http://tinyurl.com/dxb4pqg
sfw_pwd:
  - AbafR8fVrnKa
sfw_comment_form_password:
  - pa10hmvB9Nep
categories:
  - Google+
tags:
  - Google+
---
Life is interrupting us a bit. But here as a nice body awareness challenge that just might change the way you walk and dance.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <p>
    <a href='http://tangobreath.com/rediscovering-our-feet/'>Rediscovering our feet &#8211; TangoBreath the study and practice of tango.</a><br /> Two challenges to bring awareness to our oft-forgotten feet and to strengthen our connection with the ground.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/fX6hXNA69ps' target='_new'>View post on Google+</a>
  </p>