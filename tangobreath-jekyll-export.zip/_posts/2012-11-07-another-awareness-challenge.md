---
id: 293737
title: Another Awareness Challenge
date: 2012-11-07T01:19:57+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/another-awareness-challenge/
permalink: /another-awareness-challenge/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1352271663";}'
dcssb_short_url:
  - http://tinyurl.com/cs4vs8g
sfw_pwd:
  - 4qTNFeXv4JzV
sfw_comment_form_password:
  - vxmfxN2Ad9ej
categories:
  - Google+
tags:
  - Google+
---
It has been a few months since we gave an awareness challenge. Here is the first of a new series of challenges!   
It is an easy one, but one that may change how you sit, stand walk and move through every day.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <p>
    <a href='http://tangobreath.com/finding-awareness/'>Finding awareness. &#8211; TangoBreath &#8211; Argentine tango movement and dance.</a><br /> Finding awareness of our posture and movement has many rewards, here&#8217;s an exercise to help you find healthy posture and movement.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/98TsMwWZUaD' target='_new'>1</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/98TsMwWZUaD' target='_new'>View post on Google+</a>
  </p>