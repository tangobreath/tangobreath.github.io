---
id: 12728
title: Intention, Dynamic Tension, and the Line of Gravity
date: 2012-01-06T16:15:47+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/intention-dynamic-tension-and-the-line-of-gravity-2/
permalink: /intention-dynamic-tension-and-the-line-of-gravity-2/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328857237";}'
dcssb_short_url:
  - http://tinyurl.com/bnwzqhw
sfw_pwd:
  - iIvGPN3pQHOX
categories:
  - Google+
tags:
  - Google+
---
We decided to get right into the heart of tango with this one. We teach these ideas in every class because they are the foundation for all of tango. It's a bit technical, but at the same time we believe these are really basic ideas that everyone should be aware of and think about.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <p>
    <a href='http://tangobreath.com/intention-dynamic-tension-and-the-line-of-gravity/'>Intention, Dynamic Tension, and the Line of Gravity. &#8211; TangoBreath</a><br /> Dynamic Tension, Is the tension created within, as we stretch our center of movement away from our line of gravity.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/Ut62rsjbYB5' target='_new'>1</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/Ut62rsjbYB5' target='_new'>View post on Google+</a>
  </p>