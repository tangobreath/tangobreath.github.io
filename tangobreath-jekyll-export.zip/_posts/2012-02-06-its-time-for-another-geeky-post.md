---
id: 40926
title: 'It&#39;s time for another geeky post'
date: 2012-02-06T18:25:25+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/its-time-for-another-geeky-post/
permalink: /its-time-for-another-geeky-post/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328832109";}'
dcssb_short_url:
  - http://tinyurl.com/cplh6pl
sfw_pwd:
  - Wy6dJ6oEb1N1
sfw_comment_form_password:
  - rMLy0CidtQ7b
categories:
  - Google+
tags:
  - Google+
---
The line of gravity has me in it's grip.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <div style='height:120px;width:120px;overflow:hidden;float:left;margin-top:0px;padding-top:0px;margin-right:10px;vertical-align:top;text-align:center;clear:both;'>
    <img style='max-width:none;' src='https://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=http%3A%2F%2Ftangobreath.com%2Fwp-content%2Fuploads%2F2012%2F02%2Fmovingthelineofgravity.004-300x225.png' border='0' />
  </div>
  
  <p>
    <a href='http://tangobreath.com/moving-with-your-line-of-gravity/'>Moving with your line of Gravity. &#8211; TangoBreath</a><br /> The fluidity of Argentine tango movement can be vastly improved if we visualize our movement passing from and through our line of gravity.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/TmwYSWXKoSj' target='_new'>View post on Google+</a>
  </p>