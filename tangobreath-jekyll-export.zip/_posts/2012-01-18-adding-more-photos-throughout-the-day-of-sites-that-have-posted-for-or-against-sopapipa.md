---
id: 21931
title: 'Adding more photos throughout the day of sites that have posted for or against SOPA/PIPA&#8230;.'
date: 2012-01-18T12:30:03+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/adding-more-photos-throughout-the-day-of-sites-that-have-posted-for-or-against-sopapipa/
permalink: /adding-more-photos-throughout-the-day-of-sites-that-have-posted-for-or-against-sopapipa/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328863573";}'
dcssb_short_url:
  - http://tinyurl.com/cmhmzhj
sfw_pwd:
  - QSkLbnU8IE2s
sfw_comment_form_password:
  - hvcYK2KbOT56
categories:
  - Google+
tags:
  - Google+
---
**Reshared post from +[PBS NewsHour](https://plus.google.com/106351386231433168228)**

> Adding more photos throughout the day of sites that have posted for or against SOPA/PIPA. Let us know if we're missing a site in the comments

<p style='clear:both;'>
  <a href='https://plus.google.com/photos/106351386231433168228/albums/5698839421449000865'>In album SOPA Blackout: January 18, 2011 (9 photos)</a>
</p>

[<img src='https://lh4.googleusercontent.com/-ZYE3b0mHCfE/TxZYQmG7P4I/AAAAAAAAAPQ/3RNYcwhNe18/s0-d/blackoutboingboing.JPG' style='max-width:97.5%;clear:both;' border='0' />](https://lh4.googleusercontent.com/-ZYE3b0mHCfE/TxZYQmG7P4I/AAAAAAAAAPQ/3RNYcwhNe18/s0-d/blackoutboingboing.JPG)<span>http://boingboing.net</span>

<div style='float:left;display:block;height:60px;width:60px;overflow:hidden;margin-right:5px;margin-top:5px;margin-bottom:5px;'>
  <a href='https://lh3.googleusercontent.com/-DiWvP-snb5w/TxZYQx8lW8I/AAAAAAAAAPU/HBOYP_SUZqw/s0-d/blackoutcraigs.JPG'><img style='max-width:none;' src='http://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=https%3A%2F%2Flh3.googleusercontent.com%2F-DiWvP-snb5w%2FTxZYQx8lW8I%2FAAAAAAAAAPU%2FHBOYP_SUZqw%2Fw128-h61%2Fblackoutcraigs.JPG' border='0' /></a>
</div>



<div style='float:left;display:block;height:60px;width:60px;overflow:hidden;margin-right:5px;margin-top:5px;margin-bottom:5px;'>
  <a href='https://lh5.googleusercontent.com/-1hbLMuLRtHM/TxZYQ5UD93I/AAAAAAAAAPk/uf6koUxizH8/s0-d/blackoutgoogle.JPG'><img style='max-width:none;' src='http://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=https%3A%2F%2Flh5.googleusercontent.com%2F-1hbLMuLRtHM%2FTxZYQ5UD93I%2FAAAAAAAAAPk%2Fuf6koUxizH8%2Fw128-h67%2Fblackoutgoogle.JPG' border='0' /></a>
</div>



<div style='float:left;display:block;height:60px;width:60px;overflow:hidden;margin-right:5px;margin-top:5px;margin-bottom:5px;'>
  <a href='https://lh3.googleusercontent.com/-EjLY_uretqo/TxZYQ3xBpaI/AAAAAAAAAPg/uEmP17Z2GY0/s0-d/blackoutwiki.JPG'><img style='max-width:none;' src='http://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=https%3A%2F%2Flh3.googleusercontent.com%2F-EjLY_uretqo%2FTxZYQ3xBpaI%2FAAAAAAAAAPg%2FuEmP17Z2GY0%2Fw128-h68%2Fblackoutwiki.JPG' border='0' /></a>
</div>



<div style='float:left;display:block;height:60px;width:60px;overflow:hidden;margin-right:5px;margin-top:5px;margin-bottom:5px;'>
  <a href='https://lh3.googleusercontent.com/-40_RmAKWWnE/TxZYRHOsFFI/AAAAAAAAAPw/FEdXuqz-vyU/s0-d/blackoutwordpress.JPG'><img style='max-width:none;' src='http://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=https%3A%2F%2Flh3.googleusercontent.com%2F-40_RmAKWWnE%2FTxZYRHOsFFI%2FAAAAAAAAAPw%2FFEdXuqz-vyU%2Fw128-h86%2Fblackoutwordpress.JPG' border='0' /></a>
</div>



<div style='float:left;display:block;height:60px;width:60px;overflow:hidden;margin-right:5px;margin-top:5px;margin-bottom:5px;'>
  <a href='https://lh5.googleusercontent.com/-HLCwQzxPwak/TxZZeefJWJI/AAAAAAAAAQM/A5mK9slJXsc/s0-d/blackoutconsumerist.JPG'><img style='max-width:none;' src='http://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=https%3A%2F%2Flh5.googleusercontent.com%2F-HLCwQzxPwak%2FTxZZeefJWJI%2FAAAAAAAAAQM%2FA5mK9slJXsc%2Fw128-h87%2Fblackoutconsumerist.JPG' border='0' /></a>
</div>



<div style='float:left;display:block;height:60px;width:60px;overflow:hidden;margin-right:5px;margin-top:5px;margin-bottom:5px;'>
  <a href='https://lh4.googleusercontent.com/-RwpAoNEa46s/TxZbvSFon7I/AAAAAAAAAQo/4ot8_fVt3ZY/s0-d/blackoutinothernewstumblr.JPG'><img style='max-width:none;' src='http://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=https%3A%2F%2Flh4.googleusercontent.com%2F-RwpAoNEa46s%2FTxZbvSFon7I%2FAAAAAAAAAQo%2F4ot8_fVt3ZY%2Fw128-h69%2Fblackoutinothernewstumblr.JPG' border='0' /></a>
</div>



<div style='float:left;display:block;height:60px;width:60px;overflow:hidden;margin-right:5px;margin-top:5px;margin-bottom:5px;'>
  <a href='https://lh3.googleusercontent.com/-YZ0bSUFkfrg/TxZbvTvPWII/AAAAAAAAAQg/R_ss6ooQ-Oc/s0-d/blackoutmetatalk.JPG'><img style='max-width:none;' src='http://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=https%3A%2F%2Flh3.googleusercontent.com%2F-YZ0bSUFkfrg%2FTxZbvTvPWII%2FAAAAAAAAAQg%2FR_ss6ooQ-Oc%2Fw128-h69%2Fblackoutmetatalk.JPG' border='0' /></a>
</div>



<div style='float:left;display:block;height:60px;width:60px;overflow:hidden;margin-right:5px;margin-top:5px;margin-bottom:5px;'>
  <a href='https://lh5.googleusercontent.com/-dEsDtiC_3SU/TxZcLgDAdrI/AAAAAAAAAQ0/OOY5d70HdpU/s0-d/blackoutsyru.JPG'><img style='max-width:none;' src='http://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=https%3A%2F%2Flh5.googleusercontent.com%2F-dEsDtiC_3SU%2FTxZcLgDAdrI%2FAAAAAAAAAQ0%2FOOY5d70HdpU%2Fw128-h93%2Fblackoutsyru.JPG' border='0' /></a>
</div>



<p style='clear:both;'>
  <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/CVY7V2qCoFT' target='_new'>View post on Google+</a>
</p>