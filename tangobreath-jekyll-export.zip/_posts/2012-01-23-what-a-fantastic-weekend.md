---
id: 26687
title: What a fantastic weekend!
date: 2012-01-23T13:57:56+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/what-a-fantastic-weekend/
permalink: /what-a-fantastic-weekend/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328849583";}'
dcssb_short_url:
  - http://tinyurl.com/q7u54uq
sfw_pwd:
  - LKguoGw28Mfw
categories:
  - Google+
tags:
  - Google+
---
Thanks to everyone that came out to tango for the weekend.  
The classes were great and the milonga was full of energy.  
Great social time, and great dancing!

<p style='clear:both;'>
  <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/eZ9678Ehabc' target='_new'>View post on Google+</a>
</p>