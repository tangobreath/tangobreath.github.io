---
id: 12760
title: The ministry of silly wallks
date: 2012-01-06T17:09:06+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/the-ministry-of-silly-wallks/
permalink: /the-ministry-of-silly-wallks/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328847577";}'
dcssb_short_url:
  - http://tinyurl.com/cb4md7q
sfw_pwd:
  - TBiXcTjCT6ip
sfw_comment_form_password:
  - y3XiWgn9ejxv
categories:
  - Google+
  - Video
tags:
  - Google+
---
Since we had the challenge about walking, it reminded me of this. I wonder what it would be like to do silly walks with good tango technique. John Cleese is very grounded and stable in his silly walks&#8230;

<p style='clear:both;'>
</p>

<p style='clear:both;'>
  <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/TV9EeijQxrn' target='_new'>2</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/TV9EeijQxrn' target='_new'>View post on Google+</a>
</p>