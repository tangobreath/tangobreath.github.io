---
id: 153622
title: Free class on etiquette and floorcraft followed by a free milonga!
date: 2012-05-21T12:17:39+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/free-class-on-etiquette-and-floorcraft-followed-by-a-free-milonga/
permalink: /free-class-on-etiquette-and-floorcraft-followed-by-a-free-milonga/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1337619728";}'
dcssb_short_url:
  - http://tinyurl.com/c9v7ao2
sfw_pwd:
  - F8LhopqO6vkQ
sfw_comment_form_password:
  - AW5U5lxoHhGO
categories:
  - Google+
tags:
  - Google+
---
Tonight at the West Asheville Vineyard, 717 Haywood road, next to the 'Hop'.

Class starts at 7:15, The milonga starts at 8:30.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <p>
    <a href='http://tangobreath.com/beginners-tango-classes-in-asheville/'>Beginners tango classes in Asheville &#8211; TangoBreath the study and practice of Argentine tango.</a><br /> Learn Argentine tango, beginners tango classes in Asheville, NC., a 5 week series, with a free class and milonga on the 6th week.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/j5z8sMibLDy' target='_new'>View post on Google+</a>
  </p>