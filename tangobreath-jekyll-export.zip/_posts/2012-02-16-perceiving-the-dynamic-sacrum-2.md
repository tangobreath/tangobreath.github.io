---
id: 51153
title: Perceiving the dynamic sacrum
date: 2012-02-16T13:28:39+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/perceiving-the-dynamic-sacrum-2/
permalink: /perceiving-the-dynamic-sacrum-2/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1329418801";}'
dcssb_short_url:
  - http://tinyurl.com/cgce2sb
sfw_pwd:
  - WiQquBVWPr2L
sfw_comment_form_password:
  - VZJjaMHV3Jrn
categories:
  - Google+
tags:
  - Google+
---
We had a great class last night, adding dynamics to the embrace through adornos while pulling apart the ocho cortado into it's separate steps. 

Another class means we have another body awareness challenge. This time we move down the spine to the sacrum! The sacrum, sacroiliac joint and ilium bones are much more flexible than we often believe. They are very important to our overall posture, and our ability to move smoothly in tango and all other aspects.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <div style='height:120px;width:120px;overflow:hidden;float:left;margin-top:0px;padding-top:0px;margin-right:10px;vertical-align:top;text-align:center;clear:both;'>
    <img style='max-width:none;' src='https://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=http%3A%2F%2Ftangobreath.com%2Fwp-content%2Fuploads%2F2012%2F02%2FSI_joint.png' border='0' />
  </div>
  
  <p>
    <a href='http://tangobreath.com/perceiving-the-dynamic-sacrum/'>Perceiving the dynamic sacrum &#8211; TangoBreath, the study of tango</a><br /> This body awareness challenge is focused on bringing attention to the sacrum and perceiving the subtle movements in our pelvis.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/QKZQ6x1F8B4' target='_new'>View post on Google+</a>
  </p>