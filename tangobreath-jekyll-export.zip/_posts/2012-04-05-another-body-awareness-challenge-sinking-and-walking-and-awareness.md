---
id: 102793
title: 'Another Body awareness challenge!  Sinking and walking and awareness'
date: 2012-04-05T19:59:22+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/another-body-awareness-challenge-sinking-and-walking-and-awareness/
permalink: /another-body-awareness-challenge-sinking-and-walking-and-awareness/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1333670613";}'
dcssb_short_url:
  - http://tinyurl.com/bljhaju
sfw_pwd:
  - srzTGJqYgdMg
sfw_comment_form_password:
  - EukrsS816YJB
categories:
  - Google+
tags:
  - Google+
---
Become aware of and refine the movements that create your walking movement.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <p>
    <a href='http://tangobreath.com/finding-circles-and-spirals-in-our-walk/'>Finding circles and spirals in our walk. &#8211; TangoBreath, Argentine tango.</a><br /> Walking is a complex natural movement, relax into your walk and bring awareness to the circles and spirals that our body creates internally.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/QYN4iuvXZbw' target='_new'>2</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/QYN4iuvXZbw' target='_new'>View post on Google+</a>
  </p>