---
id: 22762
title: Four Hour Practica, No Classes, on January 25.
date: 2012-01-19T12:04:48+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/?p=22762
permalink: /four-hour-practica-no-classes-on-january-25/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328833050";}'
dcssb_short_url:
  - http://tinyurl.com/boup4cl
sfw_pwd:
  - Q1cpJ2dqMwD2
sfw_comment_form_password:
  - BVRX1vS8U6ys
categories:
  - Announcements
---
This Wednesday, January 25th, 2012.

There will be no classes.
  
There will be a four hour practica hosted by Lisa Jacobs.

Practica 7:00-11:00.

Admission: $8.

&nbsp;