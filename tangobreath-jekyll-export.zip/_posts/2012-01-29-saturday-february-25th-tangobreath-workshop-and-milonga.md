---
id: 32495
title: Saturday, February 25th, TangoBreath Workshop and Milonga
date: 2012-01-29T15:00:14+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/saturday-february-25th-tangobreath-workshop-and-milonga/
permalink: /saturday-february-25th-tangobreath-workshop-and-milonga/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328832110";}'
dcssb_short_url:
  - http://tinyurl.com/clvgqg5
sfw_pwd:
  - dhtQFTADPWMa
sfw_comment_form_password:
  - cIxGPCNiUyuQ
categories:
  - Google+
tags:
  - Google+
---
We are pleased to announce two special focus classes and another great Homewood milonga.

CLASSES:  
**From floor to pelvic floor: free your hip, the rest will follow.** 1-2:30 PM  
Coming to a deeper understanding of our dynamic pelvic region gives access to stable & fluid movement. Using the pelvic floor is the key to being a solid lead or follow.

**Visualizing and creating fluid movement on the path to every sacada.** 3-4:30 PM  
Learn visualization and technique to create fluid, delicious movement within the embrace, while we learn how to find all of the sacadas. This class will be equally challenging and interesting to both leaders and followers. The pelvic floor class is a pre-requisite for this class.

See our website for more details and easy registration.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <p>
    <a href='http://tangobreath.com/saturday-february-25th-milonga/'>Saturday, February 25th, TangoBreath Workshops and Milonga &#8211; TangoBreath</a><br /> Two special focus TangoBreath classes and another great Homewood milonga.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/UuisJWjYK5u' target='_new'>View post on Google+</a>
  </p>