---
id: 253212
title: Due to popular demand we are offering another class on tango foundations.
date: 2012-09-17T21:15:29+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/due-to-popular-demand-we-are-offering-another-class-on-tango-foundations/
permalink: /due-to-popular-demand-we-are-offering-another-class-on-tango-foundations/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1347934031";}'
dcssb_short_url:
  - http://tinyurl.com/cwhelyu
sfw_pwd:
  - 7xCmWy6txxoG
sfw_comment_form_password:
  - FwVo0LvnkLrt
categories:
  - Google+
tags:
  - Google+
---
**Due to popular demand we are offering another class on tango foundations.**  
We are getting back on track after an incredibly difficult summer. Coming up is our second class in a month on tango foundations. Four hours of tango for absolute beginners and advanced dancers alike. It's a great combination and everyone gets something. 

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <p>
    <a href='http://tangobreath.com/another-beginners-immersive-tango-class/'>Foundations Tango class &#8211; TangoBreath the study and practice of Argentine tango movement and dance.</a><br /> An immersive tango class for beginners and advanced dancers designed to create body awareness, good posture, movement and connection.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/DMp89P96CYa' target='_new'>View post on Google+</a>
  </p>