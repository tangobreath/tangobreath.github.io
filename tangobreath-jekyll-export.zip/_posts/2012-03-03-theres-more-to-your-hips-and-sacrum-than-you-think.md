---
id: 67234
title: 'There&#39;s more to your hips and sacrum than you think!'
date: 2012-03-03T00:05:17+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/theres-more-to-your-hips-and-sacrum-than-you-think/
permalink: /theres-more-to-your-hips-and-sacrum-than-you-think/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1330754722";}'
dcssb_short_url:
  - http://tinyurl.com/c23k65f
sfw_pwd:
  - SFLGDPycnyNJ
sfw_comment_form_password:
  - e4uVUZrV8Bw7
categories:
  - Google+
tags:
  - Google+
---
Here's a weekly challenge that will help you feel more connected to your legs and the ground.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <p>
    <a href='http://tangobreath.com/creating-stability-in-our-pelvis/'>Creating stability in our pelvis &#8211; TangoBreath, the study of tango.</a><br /> This week&#8217;s challenge involves an exercise to build flexibility and strength in our pelvis.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/T6XxC6XS8zM' target='_new'>1</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/T6XxC6XS8zM' target='_new'>View post on Google+</a>
  </p>