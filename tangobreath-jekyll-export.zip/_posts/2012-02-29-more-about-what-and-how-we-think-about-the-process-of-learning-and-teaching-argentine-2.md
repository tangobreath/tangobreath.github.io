---
id: 64557
title: 'More about what and how we think about the process of learning and teaching  Argentine&#8230;'
date: 2012-02-29T11:56:56+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/more-about-what-and-how-we-think-about-the-process-of-learning-and-teaching-argentine/
permalink: /more-about-what-and-how-we-think-about-the-process-of-learning-and-teaching-argentine-2/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1330535252";}'
dcssb_short_url:
  - http://tinyurl.com/bqnttho
sfw_pwd:
  - WUATeqq6vHyB
sfw_comment_form_password:
  - hkPgxKIvO5na
categories:
  - Google+
tags:
  - Google+
---
**More about what and how we think about the process of learning and teaching Argentine tango**

Susannah and I have spent a lot of time thinking very critically about what we have been taught, and common ways of teaching Argentine tango. Here is another article explaining our process and thoughts.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <p>
    <a href='http://tangobreath.com/a-reflection-on-learning-and-teaching-argentine-tango/'>A reflection on learning and teaching Argentine tango &#8211; TangoBreath</a><br /> Eric and I reflect on the roles of learning and teaching and our philosophy of building awareness of our tango kinesthesia.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/2CS8K7SdHbh' target='_new'>1</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/2CS8K7SdHbh' target='_new'>View post on Google+</a>
  </p>