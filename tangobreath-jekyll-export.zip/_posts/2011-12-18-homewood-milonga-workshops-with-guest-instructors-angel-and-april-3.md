---
id: 1789
title: 'Homewood Milonga &amp; Workshops with guest instructors Angel and April!'
date: 2011-12-18T22:03:40+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/homewood-milonga-workshops-with-guest-instructors-angel-and-april-3/
permalink: /homewood-milonga-workshops-with-guest-instructors-angel-and-april-3/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328863573";}'
dcssb_short_url:
  - http://tinyurl.com/c7yzwst
sfw_pwd:
  - wQo8cEAnoWYS
sfw_comment_form_password:
  - gjz7GqBV1tjz
categories:
  - Google+
tags:
  - Google+
---
We are pleased to announce our first full day of workshops followed by an  
evening milonga DJ'd by Angel Montero.

**SATURDAY, JANUARY 21st**  
Angel Montero and April Parker from Atlanta, GA

At Homewood, 19 Zillicoa.

**CLASSES**  
Surprise Boleos, 2-3:30 PM  
Spicing up your Milonga, 4:00-5:30 PM

**HOMEWOOD MILONGA DJ'd by Angel Montero**  
Amazing location, wonderful dance floor, great DJ.   
8:30 PM to 1 AM

**Private Lessons**  
April and Angel will be available for private lessons on Sunday, following the workshops. Please contact us to make arrangements. 

**PRICING**  
Full pass (both classes and milonga) $40   
A la Carte "Surprise Boleos" $25   
A la Carte "Spicing up your Milonga" $25   
Milonga $10

Visit our website for easy registration and payment.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <div style='height:120px;width:120px;overflow:hidden;float:left;margin-top:0px;padding-top:0px;margin-right:10px;vertical-align:top;text-align:center;clear:both;'>
    <img style='max-width:none;' src='http://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=http%3A%2F%2Ftangobreath.com%2Fwp-content%2Fthemes%2Ftwentyeleven%2Fimages%2FTangoBreath_white_small.jpg' border='0' />
  </div>
  
  <p>
    <a href='http://tangobreath.com/angel-and-april-workshop-and-milonga/'>Angel and April, Workshop and Milonga &#8211; TangoBreath</a><br /> Main menu. Skip to primary content. Skip to secondary content. Contact; About Us. Testimonials. What is. TangoLab; TangoBreath. Mission; When & Where; Community; Events. Saturday, Jan. 7 Milonga; &#8230;
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/ZAv57Vv76xj' target='_new'>3</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/ZAv57Vv76xj' target='_new'>View post on Google+</a>
  </p>