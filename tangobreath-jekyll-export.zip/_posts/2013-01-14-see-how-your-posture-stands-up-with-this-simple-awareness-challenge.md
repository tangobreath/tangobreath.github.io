---
id: 354939
title: See how your posture stands up with this simple awareness challenge!
date: 2013-01-14T23:03:29+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/see-how-your-posture-stands-up-with-this-simple-awareness-challenge/
permalink: /see-how-your-posture-stands-up-with-this-simple-awareness-challenge/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1358226138";}'
dcssb_short_url:
  - http://tinyurl.com/c3wtsqt
sfw_pwd:
  - wvx18AUWMQSv
sfw_comment_form_password:
  - YufqWPR8rGiD
categories:
  - Google+
tags:
  - Google+
---
**See how your posture stands up with this simple awareness challenge!**

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <p>
    <a href='http://tangobreath.com/testing-our-core-posture/'>Testing our core posture &#8211; TangoBreath the study and practice of Argentine tango movement and dance.</a><br /> Sometimes it&#8217;s good to test our posture, to see how it stands up to shifts in our center of gravity.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/Ze4KnVDSQ9U' target='_new'>1</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/Ze4KnVDSQ9U' target='_new'>View post on Google+</a>
  </p>