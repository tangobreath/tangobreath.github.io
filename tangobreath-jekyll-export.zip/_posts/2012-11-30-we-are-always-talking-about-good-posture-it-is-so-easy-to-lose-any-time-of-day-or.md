---
id: 313888
title: 'We are always talking about good posture, it is so easy to lose any time of day or&#8230;'
date: 2012-11-30T11:25:31+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/we-are-always-talking-about-good-posture-it-is-so-easy-to-lose-any-time-of-day-or/
permalink: /we-are-always-talking-about-good-posture-it-is-so-easy-to-lose-any-time-of-day-or/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1354294868";}'
dcssb_short_url:
  - http://tinyurl.com/bphsrjw
sfw_pwd:
  - 1fsOx9Bfzxqh
sfw_comment_form_password:
  - WrYSl86cptIb
categories:
  - Google+
tags:
  - Google+
---
We are always talking about good posture, it is so easy to lose any time of day or when entering into the embrace. Here are some idea's that will help you find it and keep it throughout your days and in your dance.

<http://tangobreath.com/keeping-your-good-posture-in-the-dance/>{.ot-anchor}

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <p>
    <a href='http://tangobreath.com/keeping-your-good-posture-in-the-dance/'>Keeping your good posture in the dance. &#8211; TangoBreath, Argentine tango</a><br /> Keeping your good posture in the dance is common even if we have good posture to start. Don&#8217;t lose your good posture, keep that great connection.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/Nxmi5zT7AQX' target='_new'>View post on Google+</a>
  </p>