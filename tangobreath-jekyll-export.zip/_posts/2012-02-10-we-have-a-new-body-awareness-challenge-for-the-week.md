---
id: 44852
title: We have a new body awareness challenge for the week!
date: 2012-02-10T13:45:48+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/we-have-a-new-body-awareness-challenge-for-the-week/
permalink: /we-have-a-new-body-awareness-challenge-for-the-week/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328900442";}'
dcssb_short_url:
  - http://tinyurl.com/cn3qp33
sfw_pwd:
  - OTAqGdN87qfY
categories:
  - Google+
tags:
  - Google+
---
Balance your head, improve your tango and your life.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <div style='height:120px;width:120px;overflow:hidden;float:left;margin-top:0px;padding-top:0px;margin-right:10px;vertical-align:top;text-align:center;clear:both;'>
    <img style='max-width:none;' src='https://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=http%3A%2F%2Ftangobreath.com%2Fwp-content%2Fuploads%2F2012%2F02%2FHeadforwardposture.005-150x150.png' border='0' />
  </div>
  
  <p>
    <a href='http://tangobreath.com/balance-your-head/'>Balance your head &#8211; TangoBreath, Argentine tango movement and dance.</a><br /> Prevent forward head posture, balance your head on top of your neck. Good posture is key for good Argentine tango movement.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/VGSMZAGzXPZ' target='_new'>3</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/VGSMZAGzXPZ' target='_new'>View post on Google+</a>
  </p>