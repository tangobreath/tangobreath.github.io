---
id: 12625
title: Launching instead of landing.
date: 2012-01-06T15:22:15+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/?p=12625
permalink: /tangobreath-challenges-our-first-challenge-launching-instead-of-landing/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328832092";}'
dcssb_short_url:
  - http://tinyurl.com/clafgc9
sfw_pwd:
  - URwhWh3ezeTg
sfw_comment_form_password:
  - pAwTBHP4aQ0j
categories:
  - Challenges
  - Visualization
tags:
  - awareness
  - body awareness
  - body awareness challenge
  - challenge
  - ministry of silly walks
  - movement
  - posture
  - silly walk
  - visualization
  - walking
---
From the _&#8220;ministry of silly walks&#8221;_,  this week&#8217;s challenge is a different way of thinking while walking.   As you are walking somewhere,  think about pushing off into each step rather than arriving in each step.  Think about launching instead of landing.  You may want to try it the other way around to see the difference, but primarily focus on pushing off, and let your steps land where they need to.  Explore how it feels and try different things at the same time to make your walk smooth.