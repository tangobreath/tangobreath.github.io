---
id: 22860
title: 'Weekly challenge:  Exploring your range of axis'
date: 2012-01-19T13:19:59+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/weekly-challenge-exploring-your-range-of-axis/
permalink: /weekly-challenge-exploring-your-range-of-axis/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328863573";}'
dcssb_short_url:
  - http://tinyurl.com/cdqfbtl
sfw_pwd:
  - a8loPeAfz3VS
categories:
  - Google+
tags:
  - Google+
---
We had another great class last night!   
Here is our new weekly challenge to improve body awareness, posture and movement.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <p>
    <a href='http://tangobreath.com/exploring-your-range-of-axis/'>Exploring your range of axis. &#8211; TangoBreath</a><br /> This week's challenge is about becoming aware of your line of gravity and range of axis. Your line of gravity is an imaginary line that rises vertically from the ground, through your center of gra&#8230;
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/Cv3vRWYy56J' target='_new'>View post on Google+</a>
  </p>