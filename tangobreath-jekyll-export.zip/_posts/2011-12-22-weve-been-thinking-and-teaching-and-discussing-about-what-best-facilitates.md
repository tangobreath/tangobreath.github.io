---
id: 2434
title: 'We&#39;ve been thinking and teaching, and discussing about what best facilitates&#8230;'
date: 2011-12-22T17:54:22+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/weve-been-thinking-and-teaching-and-discussing-about-what-best-facilitates/
permalink: /weve-been-thinking-and-teaching-and-discussing-about-what-best-facilitates/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328863573";}'
dcssb_short_url:
  - http://tinyurl.com/ctaqoqx
sfw_pwd:
  - ZnRehEE3jkES
sfw_comment_form_password:
  - gyuzFYIVbrAw
categories:
  - Google+
tags:
  - Google+
---
We've been thinking and teaching, and discussing about what best facilitates learning tango. There have been a lot of interesting conversations with complete beginners and experienced dancers that have led to the first of a series of posts.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <div style='height:120px;width:120px;overflow:hidden;float:left;margin-top:0px;padding-top:0px;margin-right:10px;vertical-align:top;text-align:center;clear:both;'>
    <img style='max-width:none;' src='http://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=http%3A%2F%2Ftangobreath.com%2Fwp-content%2Fuploads%2F2011%2F10%2Fcropped-tango_movement1.jpg' border='0' />
  </div>
  
  <p>
    <a href='http://tangobreath.com/expectations-misconceptions-and-perspectives-on-learning-argentine-tango/'>Expectations, misconceptions and perspectives on learning Argentine tango. &#8211; TangoBreath</a><br /> Many of us have based our learning of Tango on a point of view that is not optimal. This is what I think is wrong and how we can change our perspective to improve the learning process.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/j8Khx8sowrH' target='_new'>View post on Google+</a>
  </p>