---
id: 59342
title: Another weekly challenge about posture!
date: 2012-02-24T11:43:13+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/another-weekly-challenge-about-posture/
permalink: /another-weekly-challenge-about-posture/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1330103070";}'
dcssb_short_url:
  - http://tinyurl.com/cdabh6q
sfw_pwd:
  - rarevimhYZnu
categories:
  - Google+
tags:
  - Google+
---
We are teaching a special class tomorrow, **From floor to pelvic floor**  
It's all about how your hips, sacrum, tailbone and everything from there down work together to create a nice healthy walk that is stable, powerful and relaxed. 

Here's a body awareness challenge that will get your posture in the right place.  
Don't forget to balance your head when you are done with this one&#8230;

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <div style='height:120px;width:120px;overflow:hidden;float:left;margin-top:0px;padding-top:0px;margin-right:10px;vertical-align:top;text-align:center;clear:both;'>
    <img style='max-width:none;' src='https://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=http%3A%2F%2Ftangobreath.com%2Fwp-content%2Fuploads%2F2012%2F02%2Fpelvislateral-150x150.jpg' border='0' />
  </div>
  
  <p>
    <a href='http://tangobreath.com/aligning-our-sacrum/'>Aligning our sacrum &#8211; TangoBreath, the study and practice of tango</a><br /> Being able to adjust your sacrum in small ways will help not only with your stability and technique in tango, but it also will help in the long run with back, hip, and knee health.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/Y41MRnEFXpt' target='_new'>4</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/Y41MRnEFXpt' target='_new'>View post on Google+</a>
  </p>