---
id: 17511
title: 'We had a great class class last night!  Every class comes with a weekly challenge&#8230;'
date: 2012-01-12T15:33:40+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/we-had-a-great-class-class-last-night-every-class-comes-with-a-weekly-challenge/
permalink: /we-had-a-great-class-class-last-night-every-class-comes-with-a-weekly-challenge/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328863573";}'
dcssb_short_url:
  - http://tinyurl.com/c7ffcu4
sfw_pwd:
  - sdIrIEqjrfKX
categories:
  - Google+
tags:
  - Google+
---
We had a great class class last night! Every class comes with a weekly challenge to improve body awareness, posture and movement. Here is this week's challenge.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <p>
    <a href='http://tangobreath.com/wear-movement-like-a-cloak/'>Wear movement like a cloak &#8211; TangoBreath</a><br /> Imagine your movement originates from the back of a cloak you are wearing. Weaving all movement across your back and through your body.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/Amm6aNfzsHk' target='_new'>View post on Google+</a>
  </p>