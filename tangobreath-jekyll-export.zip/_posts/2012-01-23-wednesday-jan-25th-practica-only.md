---
id: 26680
title: Wednesday, Jan 25th, Practica Only
date: 2012-01-23T13:59:47+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/?p=26680
permalink: /wednesday-jan-25th-practica-only/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328832110";}'
dcssb_short_url:
  - http://tinyurl.com/c837spc
sfw_pwd:
  - fOxqRKfLhD1P
sfw_comment_form_password:
  - 0KKZQmbXy7og
categories:
  - Announcements
  - Asheville Events
tags:
  - Asheville
  - Asheville tango
  - practica
  - tango asheville
---
This Wednesday we will be having a special 4 hour practica hosted by Lisa Jacobs.

7:00 &#8211; 11:00.

Admission $8

Classes will resume next week.