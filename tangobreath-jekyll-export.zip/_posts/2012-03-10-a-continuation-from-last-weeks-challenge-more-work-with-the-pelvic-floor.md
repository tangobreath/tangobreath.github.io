---
id: 75099
title: 'A continuation from last week&#39;s challenge, more work with the pelvic floor.'
date: 2012-03-10T13:14:39+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/a-continuation-from-last-weeks-challenge-more-work-with-the-pelvic-floor/
permalink: /a-continuation-from-last-weeks-challenge-more-work-with-the-pelvic-floor/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1331406572";}'
dcssb_short_url:
  - http://tinyurl.com/brsaoah
sfw_pwd:
  - yyij2JCWvXCG
sfw_comment_form_password:
  - G5hpnkI3Me14
categories:
  - Google+
tags:
  - Google+
---
**A continuation from last week's challenge, more work with the pelvic floor.**

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <p>
    <a href='http://tangobreath.com/finding-release-in-the-pelvis/'>Finding release in the pelvis &#8211; TangoBreath, the practice of tango.</a><br /> Continuing last week&#8217;s challenge, we will find ways to release and relax the joints in our pelvis, which is key to building resiliency and balance.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/b8Ku2LBX2Ut' target='_new'>1</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/b8Ku2LBX2Ut' target='_new'>View post on Google+</a>
  </p>