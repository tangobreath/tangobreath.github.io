---
id: 3575
title: '&#39;Buche de Noel&#39;, a classic traditional &#39;yule log&#39; chocolate ganache&#8230;'
date: 2011-12-24T11:32:22+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/buche-de-noel-a-classic-traditional-yule-log-chocolate-ganache/
permalink: /buche-de-noel-a-classic-traditional-yule-log-chocolate-ganache/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328863573";}'
dcssb_short_url:
  - http://tinyurl.com/d8omm6x
sfw_pwd:
  - kPnmrYIsvRjR
sfw_comment_form_password:
  - Ma7XBbpIj8Pa
categories:
  - Google+
tags:
  - Google+
---
**'Buche de Noel', a classic traditional 'yule log' chocolate ganache cake**

This is what Susannah made for all of us to eat after class last Wednesday. It went fast. The mushrooms looked so real! Nice dark chocolate, not too sweet although the mushrooms were a bit sweet.

Happy Holidays!  
[<img src='https://lh6.googleusercontent.com/-80WxDgkyaVU/TvX9jpZyzFI/AAAAAAAAADU/wZsksjk-Y1I/yule_log.JPG' style='max-width:97.5%;clear:both;' border='0' />](https://lh6.googleusercontent.com/-80WxDgkyaVU/TvX9jpZyzFI/AAAAAAAAADU/wZsksjk-Y1I/yule_log.JPG)<span></span>

<div style='float:left;display:block;height:60px;width:60px;overflow:hidden;margin-right:5px;margin-top:5px;margin-bottom:5px;'>
  <a href='https://lh5.googleusercontent.com/-zso-UKsl1CQ/TvX9kLSjBFI/AAAAAAAAADI/q_KWksvSJD0/yule_log2.JPG'><img style='max-width:none;' src='http://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=https%3A%2F%2Flh5.googleusercontent.com%2F-zso-UKsl1CQ%2FTvX9kLSjBFI%2FAAAAAAAAADI%2Fq_KWksvSJD0%2Fs288%2Fyule_log2.JPG' border='0' /></a>
</div>



<p style='clear:both;'>
  <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/dBW7YRkdmqU' target='_new'>1</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/dBW7YRkdmqU' target='_new'>View post on Google+</a>
</p>