---
id: 36674
title: Time for another weekly body awareness challenge
date: 2012-02-02T15:35:24+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/time-for-another-weekly-body-awareness-challenge/
permalink: /time-for-another-weekly-body-awareness-challenge/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328832110";}'
dcssb_short_url:
  - http://tinyurl.com/bll9sfm
sfw_pwd:
  - 6EEzrI3k8JGq
sfw_comment_form_password:
  - OC7vRzqiTAuZ
categories:
  - Google+
tags:
  - Google+
---
This one is something we should all do any time we can think of it.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <div style='height:120px;width:120px;overflow:hidden;float:left;margin-top:0px;padding-top:0px;margin-right:10px;vertical-align:top;text-align:center;clear:both;'>
    <img style='max-width:none;' src='https://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=http%3A%2F%2Ftangobreath.com%2Fwp-content%2Fuploads%2F2012%2F01%2Fbody_awareness_challenges.jpeg' border='0' />
  </div>
  
  <p>
    <a href='http://tangobreath.com/scrunch-your-shoulders-fix-your-posture/'>Scrunch your shoulders. &#8211; TangoBreath</a><br /> Readjust your upper back, shoulders, neck and head to reestablish good posture after sitting.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/KSgs5u9sKRt' target='_new'>1</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/KSgs5u9sKRt' target='_new'>View post on Google+</a>
  </p>