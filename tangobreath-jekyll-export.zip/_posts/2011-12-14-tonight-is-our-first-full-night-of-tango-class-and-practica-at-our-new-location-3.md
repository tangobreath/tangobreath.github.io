---
id: 1790
title: Tonight is our first full night of tango class and practica at our new location!
date: 2011-12-14T15:04:34+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/tonight-is-our-first-full-night-of-tango-class-and-practica-at-our-new-location-3/
permalink: /tonight-is-our-first-full-night-of-tango-class-and-practica-at-our-new-location-3/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1329111658";}'
dcssb_short_url:
  - http://tinyurl.com/c4tjy5p
sfw_pwd:
  - VHJufF6y9AZS
sfw_comment_form_password:
  - xsbSMxdWNz1L
categories:
  - Google+
tags:
  - Google+
---
**Tonight is our first full night of tango class and practica at our new location!**

Susannah has made some amazing pumpkin bread with an apple/citrus glaze.   
The bread will taste amazing along side her fantastic hot cider.

It's a good thing she made extra!

Classes start at 7:00, the practica starts at 9:00. BYOB.

Lisa Jacobs will be our DJ.  
[<img src='https://lh6.googleusercontent.com/-mt5vA4Iajm0/Tuj_G13mX4I/AAAAAAAAACc/WDT7dogW-vE/pumpkin_bread.png' style='max-width:97.5%;clear:both;' border='0' />](https://lh6.googleusercontent.com/-mt5vA4Iajm0/Tuj_G13mX4I/AAAAAAAAACc/WDT7dogW-vE/pumpkin_bread.png)<span></span>

<p style='clear:both;'>
  <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/Uj3Jkijmrfc' target='_new'>View post on Google+</a>
</p>