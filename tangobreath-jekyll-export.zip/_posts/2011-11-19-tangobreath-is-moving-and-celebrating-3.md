---
id: 1792
title: TangoBreath is moving and Celebrating!
date: 2011-11-19T13:48:28+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/tangobreath-is-moving-and-celebrating-3/
permalink: /tangobreath-is-moving-and-celebrating-3/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328903078";}'
dcssb_short_url:
  - http://tinyurl.com/dxfn8r9
sfw_pwd:
  - CN8Mc57AozZX
sfw_comment_form_password:
  - qcg9PCxJYeln
categories:
  - Google+
tags:
  - Google+
---
We are so very excited to announce our new location at **Homewood, 19 Zillicoa**, in the historic Montford neighborhood of Asheville, NC.   
Homewood has an amazing ballroom with great floors and a warm atmosphere.

Our new home will allow us to expand our evenings to include a 2-3 hour practica  
following our regular TangoBreath & TangoLab sessions.

To celebrate, we cordially invite you to join us for a milonga on our first night in our new home on Wednesday, December 7th.

There will be a one hour TangoBreath starting at 7:00.   
From 8:00 &#8211; 12:00 there will be a milonga DJ'd by Lisa Jacobs.  
Snacks, hot cider, and some wine will be provided. BYOB.

Join us for a lovely evening, wonderful dances, great music, and good company in a magical place! 

Wednesday December 7th,  
7:00-8:00 TangoBreath  
8:00-12:00 Milonga

Admission for the entire night is $5.

We hope to see you there!

With gratitude and appreciation,

Eric & Susannah

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <p>
    <a href='http://www.mybelovedhomewood.com/'>Homewood, Inc / Welcome / Welcome</a><br /> Asheville Wedding venue, 1 mile north of Downtown, with ceremony location on site. 1927 Stone Manor in post victorian neighborhood.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/MwpAENxuRv3' target='_new'>1</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/MwpAENxuRv3' target='_new'>View post on Google+</a>
  </p>