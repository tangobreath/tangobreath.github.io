---
id: 1788
title: 'Here is a nice post about kiki and bouba and how +Murat Erdemsel  links them to tango&#8230;'
date: 2011-12-20T20:02:59+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/here-is-a-nice-post-about-kiki-and-bouba-and-how-murat-erdemsel-links-them-to-tango-3/
permalink: /here-is-a-nice-post-about-kiki-and-bouba-and-how-murat-erdemsel-links-them-to-tango-3/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328863573";}'
dcssb_short_url:
  - http://tinyurl.com/bwzne6n
sfw_pwd:
  - ildi38adzYkf
sfw_comment_form_password:
  - uJla9LBVck7y
categories:
  - Google+
tags:
  - Google+
---
Here is a nice post about kiki and bouba and how <span class="proflinkWrapper"><span class="proflinkPrefix">+</span><a href="https://plus.google.com/104671820784218116275" class="proflink" oid="104671820784218116275">Murat Erdemsel</a></span> links them to tango music. We use these idea's to help our students learn to hear the music and the phrasing within. We even have colored paper cutouts on wands, to help with the idea. Believe it or not Biagi's 'Racing club' is a great example of kiki and bouba phrasing. Another favorite of ours is Di Sarli's 'No Esta'. There are numerous choices that show these basic idea's and even more that blur the lines by combining kiki and bouba as melodies and counter melodies,fills and accents. Dancing to both kiki and bouba at the same time is full of possibilities and the results can be amazing.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <div style='height:120px;width:120px;overflow:hidden;float:left;margin-top:0px;padding-top:0px;margin-right:10px;vertical-align:top;text-align:center;clear:both;'>
    <img style='max-width:none;' src='http://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=http%3A%2F%2F3.bp.blogspot.com%2F-hQZEPyYDdL4%2FTtMoBLrpL5I%2FAAAAAAAALLI%2FESE1pzIyPjs%2Fs400%2Fimage.jpeg' border='0' />
  </div>
  
  <p>
    <a href='http://riowang.blogspot.com/2011/12/kiki-bouba-and-contours-of-tango.html?spref'>Poemas del río Wang: Kiki, Bouba, and the contours of tango</a><br /> Kiki, Bouba, and the contours of tango. Since childhood, I never liked the oval Since childhood, I always drew the angle Pavel Kogan. “Thunderstorm”, 1936. Murat Erdemsel, a tango teacher with 10 year&#8230;
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/88uYYkxWFNM' target='_new'>1</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/88uYYkxWFNM' target='_new'>View post on Google+</a>
  </p>