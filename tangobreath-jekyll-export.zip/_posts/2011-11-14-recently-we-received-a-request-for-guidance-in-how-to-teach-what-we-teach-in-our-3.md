---
id: 1794
title: 'Recently we received a request for guidance in how to teach what we teach in our&#8230;'
date: 2011-11-14T23:08:34+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/recently-we-received-a-request-for-guidance-in-how-to-teach-what-we-teach-in-our-3/
permalink: /recently-we-received-a-request-for-guidance-in-how-to-teach-what-we-teach-in-our-3/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328969504";}'
dcssb_short_url:
  - http://tinyurl.com/cbncn59
sfw_pwd:
  - f6J9VPtZsuxH
sfw_comment_form_password:
  - pk5sISHejaab
categories:
  - Google+
tags:
  - Google+
---
Recently we received a request for guidance in how to teach what we teach in our classes. This turned out to be a tough question. Teaching has to come from within, and in your own way. We can't tell you how to teach, but Susannah wrote a really nice essay on what we did to arrive where we are. 

After she wrote it we found a really nice quote by Irene Dowd, 

"The work of a teacher is to give students the tools of knowledge and skills to help themselves change their own patterns of movement. The good teacher gives the student the ability to be self-responsible. Effective teachers make themselves obsolete in the end."

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <div style='height:120px;width:120px;overflow:hidden;float:left;margin-top:0px;padding-top:0px;margin-right:10px;vertical-align:top;text-align:center;clear:both;'>
    <img style='max-width:none;' src='http://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=http%3A%2F%2Ftangobreath.com%2Fwp-content%2Fthemes%2Ftwentyeleven%2Fimages%2FTangoBreath_white_small.jpg' border='0' />
  </div>
  
  <p>
    <a href='http://tangobreath.com/learning-to-question-in-order-to-learn/'>Learning to question in order to learn</a><br /> Learning to question what you've learned in order to learn more deeply.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/e5Rz36q9FFg' target='_new'>View post on Google+</a>
  </p>