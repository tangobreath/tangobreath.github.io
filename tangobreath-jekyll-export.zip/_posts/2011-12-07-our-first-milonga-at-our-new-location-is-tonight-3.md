---
id: 1791
title: Our first milonga at our new location is tonight!
date: 2011-12-07T13:27:08+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/our-first-milonga-at-our-new-location-is-tonight-3/
permalink: /our-first-milonga-at-our-new-location-is-tonight-3/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1329111658";}'
dcssb_short_url:
  - http://tinyurl.com/cvja6hx
sfw_pwd:
  - Sd3QgNRkeSX0
sfw_comment_form_password:
  - crhyzdrBAEvK
categories:
  - Google+
tags:
  - Google+
---
After tonight our new Wednesday format will include a practica following class.

7:00 &#8211; TangoBreath vinyasa flow.  
8:00 &#8211; TangoLab  
9:00 &#8211; 11:00 &#8211; Practica.

See our website for more information. 

<http://www.tangobreath.com>  
[<img src='https://lh4.googleusercontent.com/-P_v64_705HE/Tt-uc_jRLBI/AAAAAAAAAB0/AZGri4eZEpU/TangoBreath.002.png' style='max-width:97.5%;clear:both;' border='0' />](https://lh4.googleusercontent.com/-P_v64_705HE/Tt-uc_jRLBI/AAAAAAAAAB0/AZGri4eZEpU/TangoBreath.002.png)<span></span>

<p style='clear:both;'>
  <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/K6t5VAQzFHm' target='_new'>1</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/K6t5VAQzFHm' target='_new'>View post on Google+</a>
</p>