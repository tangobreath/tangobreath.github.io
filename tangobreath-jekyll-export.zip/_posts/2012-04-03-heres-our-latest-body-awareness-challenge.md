---
id: 100474
title: 'Here&#39;s our latest body awareness challenge'
date: 2012-04-03T14:47:53+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/heres-our-latest-body-awareness-challenge/
permalink: /heres-our-latest-body-awareness-challenge/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1333502185";}'
dcssb_short_url:
  - http://tinyurl.com/cpp2cb8
sfw_pwd:
  - G1ZwL5n6UUfo
sfw_comment_form_password:
  - XxSiKHeZtwDO
categories:
  - Google+
tags:
  - Google+
---
Sink into your standing leg and find  
the ground from the top down!

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <p>
    <a href='http://tangobreath.com/sinking-into-our-standing-leg/'>Sinking into our standing leg &#8211; TangoBreath the study and practice of Argentine tango movement and dance.</a><br /> Our latest challenge is to create awarenes of the relationship between the pelvis and our upper body. Sinking into the ground starting from our shoulder, creates stability and strength in our positio&#8230;
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/LF9ECci854c' target='_new'>1</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/LF9ECci854c' target='_new'>View post on Google+</a>
  </p>