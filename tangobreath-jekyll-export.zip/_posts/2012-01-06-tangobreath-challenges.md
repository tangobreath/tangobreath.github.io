---
id: 12696
title: TangoBreath Challenges
date: 2012-01-06T15:46:14+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/tangobreath-challenges/
permalink: /tangobreath-challenges/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328857988";}'
dcssb_short_url:
  - http://tinyurl.com/crve3mz
sfw_pwd:
  - uLFDoOVmeGsC
sfw_comment_form_password:
  - 3rjX5XqqTDSr
categories:
  - Google+
tags:
  - Google+
---
Each week at the end of class, we give a challenge to be done during the week. We discuss the results the next week. The challenges can be anything from a visualization while walking down the street, to something to think about every time we stand up. Starting this week, we will be posting the challenges on our website in a special category called challenges.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <div style='height:120px;width:120px;overflow:hidden;float:left;margin-top:0px;padding-top:0px;margin-right:10px;vertical-align:top;text-align:center;clear:both;'>
    <img style='max-width:none;' src='http://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=http%3A%2F%2Ftangobreath.com%2Fwp-content%2Fthemes%2Ftwentyeleven%2Fimages%2FTangoBreath_white_small.jpg' border='0' />
  </div>
  
  <p>
    <a href='http://tangobreath.com/tangobreath-challenges-our-first-challenge-launching-instead-of-landing/'>TangoBreath Challenges, our first challenge, launching instead of landing. &#8211; TangoBreath</a><br /> An everyday challenge, to build body awareness, launching instead of landing.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/HHo31QFDWgJ' target='_new'>View post on Google+</a>
  </p>