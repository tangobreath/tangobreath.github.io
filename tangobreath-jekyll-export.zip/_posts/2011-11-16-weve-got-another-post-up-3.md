---
id: 1793
title: 'We&#39;ve got another post up'
date: 2011-11-16T13:45:42+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/weve-got-another-post-up-3/
permalink: /weve-got-another-post-up-3/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1329070654";}'
dcssb_short_url:
  - http://tinyurl.com/cy48qwc
sfw_pwd:
  - 67YZbEJd1bUw
sfw_comment_form_password:
  - jq4Svhs8kRug
categories:
  - Google+
tags:
  - Google+
---
This one is about how our thinking affects the way we move. I hope you like it.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <div style='height:120px;width:120px;overflow:hidden;float:left;margin-top:0px;padding-top:0px;margin-right:10px;vertical-align:top;text-align:center;clear:both;'>
    <img style='max-width:none;' src='http://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=http%3A%2F%2Ftangobreath.com%2Fwp-content%2Fthemes%2Ftwentyeleven%2Fimages%2FTangoBreath_white.jpg' border='0' />
  </div>
  
  <p>
    <a href='http://tangobreath.com'>TangoBreath &#8211; The study and practice of Argentine tango movement</a><br /> How we think affects the way we move. Posted on November 15, 2011 by Eric Gebhart. TangoBreath has made us very conscious of how we describe the movements we are guiding. It is crucial to be concise i&#8230;
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/P7fNjsKfTFG' target='_new'>View post on Google+</a>
  </p>