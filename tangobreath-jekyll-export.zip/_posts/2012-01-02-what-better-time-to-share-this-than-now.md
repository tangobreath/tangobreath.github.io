---
id: 9903
title: What better time to share this than now
date: 2012-01-02T19:32:53+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/what-better-time-to-share-this-than-now/
permalink: /what-better-time-to-share-this-than-now/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328847577";}'
dcssb_short_url:
  - http://tinyurl.com/d4ew73m
sfw_pwd:
  - qGcKKPtFXUPl
categories:
  - Google+
  - Video
tags:
  - Google+
---
The amazing musicality of Andrea Missé! What a loss. Thank you for the video <span class="proflinkWrapper"><span class="proflinkPrefix">+</span><a href="https://plus.google.com/108592619439356152685" class="proflink" oid="108592619439356152685">Miles Tangos</a></span>.

<p style='clear:both;'>
</p>

<p style='clear:both;'>
  <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/LqrYR2UjJpD' target='_new'>1</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/LqrYR2UjJpD' target='_new'>View post on Google+</a>
</p>