---
id: 48126
title: Lately we have been giving body awareness challenges to improve posture
date: 2012-02-13T16:04:15+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/lately-we-have-been-giving-body-awareness-challenges-to-improve-posture/
permalink: /lately-we-have-been-giving-body-awareness-challenges-to-improve-posture/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1329170439";}'
dcssb_short_url:
  - http://tinyurl.com/btb7odw
sfw_pwd:
  - Lk0GRFgqdRKx
sfw_comment_form_password:
  - V9dylOAM8jYE
categories:
  - Google+
tags:
  - Google+
---
Here's a post that talks about posture and tango in more depth.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <div style='height:120px;width:120px;overflow:hidden;float:left;margin-top:0px;padding-top:0px;margin-right:10px;vertical-align:top;text-align:center;clear:both;'>
    <img style='max-width:none;' src='https://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=http%3A%2F%2Ftangobreath.com%2Fwp-content%2Fuploads%2F2012%2F02%2FHeadforwardposture.005-150x150.png' border='0' />
  </div>
  
  <p>
    <a href='http://tangobreath.com/forward-head-posture-and-argentine-tango/'>Forward head posture and Argentine tango &#8211; TangoBreath</a><br /> Forward head posture is bad for us and is the source of many possible problems in our Argentine tango movement. Awareness is the first step.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/iu9raXdMKpN' target='_new'>1</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/iu9raXdMKpN' target='_new'>View post on Google+</a>
  </p>