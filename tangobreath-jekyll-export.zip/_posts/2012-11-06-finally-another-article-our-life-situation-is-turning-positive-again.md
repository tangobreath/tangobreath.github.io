---
id: 293230
title: Finally! Another article. Our life situation is turning positive again
date: 2012-11-06T10:39:16+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/finally-another-article-our-life-situation-is-turning-positive-again/
permalink: /finally-another-article-our-life-situation-is-turning-positive-again/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1352217974";}'
dcssb_short_url:
  - http://tinyurl.com/cjmnapg
sfw_pwd:
  - xsHFg2fA66di
categories:
  - Google+
tags:
  - Google+
---
Due to a rather stressful summer it has been a few months since we have posted anything on our website. Thankfully life is beginning to return to normal whatever that is. It at least does not involve a hostile work environment! 

I wrote this article at the beginning of the summer at a time when these thoughts carried a great deal of emotion as well as meaning. Months later this article still rings true for me.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <p>
    <a href='http://tangobreath.com/our-tango-our-life-and-self-perception/'>Our tango, our life, and self perception &#8211; TangoBreath the study and practice of Argentine tango movement and dance.</a><br /> Our tango, our life, and self perception are reflections of one another. Our life experience effects our tango, and our tango effects our life.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/2gZQCyCcfMi' target='_new'>2</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/2gZQCyCcfMi' target='_new'>View post on Google+</a>
  </p>