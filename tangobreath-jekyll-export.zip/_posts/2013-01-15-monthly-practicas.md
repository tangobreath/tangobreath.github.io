---
id: 351964
title: Monthly Practica
date: 2013-01-15T11:04:05+00:00
author: Susannah
layout: post
guid: http://tangobreath.com/?p=351964
permalink: /monthly-practicas/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1358261038";}'
dcssb_short_url:
  - http://tinyurl.com/c837spc
sfw_pwd:
  - i8XmEoijG2HI
sfw_comment_form_password:
  - m7Qk88Wf1mDn
image: /wp-content/uploads/2013/01/Practica-header.003.png
categories:
  - Announcements
  - Asheville Events
  - Beginning
  - Events
  - Practice
tags:
  - argentine tango
  - Asheville
  - Asheville tango
  - awareness
  - class
  - learning
  - learning tango
  - practica
  - practice
---
### Join us for our practica on the third Saturday of every month!

## <span class="Apple-style-span" style="font-size: 13px; font-weight: normal;">Located at the <a href="https://maps.google.com/maps?oe=utf-8&q=717+Haywood+Road,+Asheville+NC&ie=UTF-8&hq=&hnear=0x88598ced24a2c15b:0xb9fe319ba607243e,717+Haywood+Rd,+Asheville,+NC+28806&gl=us&ei=rX7wULr7E5Ks8QSM9oCABA&ved=0CDQQ8gEwAA" target="_blank">West Asheville Vineyard</a>, 717 Haywood Road, right next to The Hop in West Asheville.</span>

### SATURDAYS

**February 23rd &#8212; March 16th &#8212; April 20th**

7:00 &#8211; 9:30 PM

<!--more-->

**$5 at the door**

Practica is intended to be a time where you can work on what you are studying, incorporate new concepts, and give and get feedback from other dancers. In a practica setting, it is appropriate to stop and talk about the dance and work things out (if you will be interfering with the line of dance, you may step to the outside or to the middle of the dance space). A practica is also a wonderful time to get to know members of the community, if you are just starting out or are new to Asheville.

The West Asheville vinyard is a comfortable place, with comfortable chairs and lighting.  And it a has a really nice dance floor.

Eric and Susannah will be available during the practica to assist and provide feedback.

**Questions? **

<a title="Contact" href="http://tangobreath.com/contact/" target="_blank">Email us</a> or call us at 919.632.1742