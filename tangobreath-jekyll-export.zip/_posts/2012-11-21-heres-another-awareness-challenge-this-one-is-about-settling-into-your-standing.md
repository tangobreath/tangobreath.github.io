---
id: 306081
title: 'Here&#39;s another awareness challenge! This one is about settling into your standing&#8230;'
date: 2012-11-21T12:48:26+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/heres-another-awareness-challenge-this-one-is-about-settling-into-your-standing/
permalink: /heres-another-awareness-challenge-this-one-is-about-settling-into-your-standing/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1353520951";}'
dcssb_short_url:
  - http://tinyurl.com/cgu9jy8
sfw_pwd:
  - 9vqLIBhRCTje
sfw_comment_form_password:
  - L3z0cznkvUys
categories:
  - Google+
tags:
  - Google+
---
Here's another awareness challenge! This one is about settling into your standing posture. This is so simple and so very important in your dance and in the way you stand and move everywhere you go.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <p>
    <a href='http://tangobreath.com/changing-weight-and-settling/'>Changing weight and Settling. &#8211; TangoBreath &#8211; Argentine tango movement and dance.</a><br /> Changing weight and settling is the most fundamental movement of Argentine tango, here are some visualizations to help in it&#8217;s practice.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/RzWLC8mkV43' target='_new'>1</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/RzWLC8mkV43' target='_new'>View post on Google+</a>
  </p>