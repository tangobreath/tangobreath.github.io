---
id: 329968
title: From the Ministry of Silly Walks
date: 2012-12-18T12:20:01+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/from-the-ministry-of-silly-walks/
permalink: /from-the-ministry-of-silly-walks/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1355853749";}'
dcssb_short_url:
  - http://tinyurl.com/co6vocz
sfw_pwd:
  - RBcxOZIMkLlX
sfw_comment_form_password:
  - PbBAdRwnvsfF
categories:
  - Google+
tags:
  - Google+
---
We have another awareness challenge. This one is from the ministry of silly walks. Find balance and stability, your free hip, contrabody spiral and a relaxed comfortable walk by experimenting with this new silly walk.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <p>
    <a href='http://tangobreath.com/silly-anesthetized-walk/'>Silly anesthetized walk</a><br /> The silly anesthetized walk is to help you find stability and engagement with the ground while relaxing and finding a &#8216;loose leg&#8217;.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/a17jWsSiPjG' target='_new'>3</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/a17jWsSiPjG' target='_new'>View post on Google+</a>
  </p>