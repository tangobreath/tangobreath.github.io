---
id: 300891
title: 'This is a bit more than one of our awareness challenges, but that&#39;s what it takes&#8230;'
date: 2012-11-15T11:08:36+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/this-is-a-bit-more-than-one-of-our-awareness-challenges-but-thats-what-it-takes/
permalink: /this-is-a-bit-more-than-one-of-our-awareness-challenges-but-thats-what-it-takes/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1352998892";}'
dcssb_short_url:
  - http://tinyurl.com/d9dmv34
sfw_pwd:
  - eU4cJLxVfqKZ
sfw_comment_form_password:
  - tTSWBHASjMxy
categories:
  - Google+
tags:
  - Google+
---
This is a bit more than one of our awareness challenges, but that's what it takes to fine tune you posture. Everyone should be good at this. It takes less than half a minute once you get used to doing it. You'll feel better in more ways than one.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <p>
    <a href='http://tangobreath.com/fine-tune-your-posture/'>Fine-tune your posture &#8211; TangoBreath &#8211; tango movement and dance.</a><br /> Fine-tuning your posture is important in life and Argentine tango. Become aware your posture and how to adjust it in a holistic way.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/NVcagYYFbnM' target='_new'>1</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/NVcagYYFbnM' target='_new'>View post on Google+</a>
  </p>