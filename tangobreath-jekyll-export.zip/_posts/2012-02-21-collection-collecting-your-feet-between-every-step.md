---
id: 56522
title: Collection, collecting your feet between every step
date: 2012-02-21T17:15:09+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/collection-collecting-your-feet-between-every-step/
permalink: /collection-collecting-your-feet-between-every-step/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1329865243";}'
dcssb_short_url:
  - http://tinyurl.com/dygg566
sfw_pwd:
  - mAHDtqSeDe1T
sfw_comment_form_password:
  - ixMOh04KfC2k
categories:
  - Google+
tags:
  - Google+
---
It sounds like a bad idea to me, it can't be good for your Argentine tango.

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <div style='height:120px;width:120px;overflow:hidden;float:left;margin-top:0px;padding-top:0px;margin-right:10px;vertical-align:top;text-align:center;clear:both;'>
    <img style='max-width:none;' src='https://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=http%3A%2F%2Ftangobreath.com%2Fwp-content%2Fuploads%2F2012%2F02%2Fmodels-197x300.jpg' border='0' />
  </div>
  
  <p>
    <a href='http://tangobreath.com/thinking-about-collection-is-bad-for-your-tango/'>Collection is bad for your tango. &#8211; TangoBreath.</a><br /> Collection is something everyone is taught, yet teaches nothing worth keeping and has many bad side effects that must be unlearned.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> Reshared <a href='https://plus.google.com/113145648275577627533/posts/VaxqeSJaaE4' target='_new'>1</a> times<br /> <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/VaxqeSJaaE4' target='_new'>View post on Google+</a>
  </p>