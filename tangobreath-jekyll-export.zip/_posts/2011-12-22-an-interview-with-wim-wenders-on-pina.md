---
id: 2564
title: An interview with Wim Wenders on PIna
date: 2011-12-22T22:57:01+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/an-interview-with-wim-wenders-on-pina/
permalink: /an-interview-with-wim-wenders-on-pina/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328863573";}'
dcssb_short_url:
  - http://tinyurl.com/btqqzrm
sfw_pwd:
  - 9QX48GLDo3yT
sfw_comment_form_password:
  - hJQmmfaH19un
categories:
  - Google+
tags:
  - Google+
---
**Reshared post from +[Fred Sullivan](https://plus.google.com/109767214205105679538)**

> An interview with Wim Wenders on PIna. Why 3D is essential for filming dance and why he continued to make the movie after Pina's death. <http://nyti.ms/rpzy1c>

<p style='clear:both;'>
  <p style='margin-bottom:5px;'>
    <strong>Embedded Link</strong>
  </p>
  
  <div style='height:120px;width:120px;overflow:hidden;float:left;margin-top:0px;padding-top:0px;margin-right:10px;vertical-align:top;text-align:center;clear:both;'>
    <img style='max-width:none;' src='http://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&#038;gadget=a&#038;resize_h=100&#038;url=http%3A%2F%2Fgraphics8.nytimes.com%2Fimages%2F2011%2F12%2F11%2Farts%2F11WENDERS1_SPAN%2F11WENDERS1_SPAN-articleLarge-v2.jpg' border='0' />
  </div>
  
  <p>
    <a href='http://nyti.ms/rpzy1c'>Wim Wenders on ‘Pina,’ His Film on Pina Bausch’s Dances</a><br /> The German director Wim Wenders has created “Pina,” a 3-D tribute to the choreographer Pina Bausch, who died in 2009.
  </p>
  
  <p style='clear:both;'>
    <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/8zXUdb7CkyK' target='_new'>View post on Google+</a>
  </p>