---
id: 26686
title: TangoBreath in Durham, NC tonight
date: 2012-01-23T13:59:25+00:00
author: Eric Gebhart
layout: post
guid: http://tangobreath.com/tangobreath-in-durham-nc-tonight/
permalink: /tangobreath-in-durham-nc-tonight/
keyword_cache:
  - 'a:1:{s:13:"keywords_time";s:10:"1328832110";}'
dcssb_short_url:
  - http://tinyurl.com/d4j7syn
sfw_pwd:
  - EusO8CA2Fcgn
categories:
  - Google+
tags:
  - Google+
---
If anyone is in the area, come on out to Jae's classes at the Triangle Dance Studio.  
We will be teaching TangoBreath for her first class!

<p style='clear:both;'>
  <strong>Google+:</strong> <a href='https://plus.google.com/113145648275577627533/posts/aDcCLSsbFXR' target='_new'>View post on Google+</a>
</p>