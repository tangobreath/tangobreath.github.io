---
id: 55467
title: My Philosophy
date: 2018-10-06T15:22:18+00:00
author: Eric Gebhart
layout: page
guid: http://tangobreath.com/?page_id=55467
keyword_cache:
  - 'a:1:{s:13:"keywords_time";i:1417323878;}'
---
&nbsp;

There are many styles of tango, and there are many styles of learning and teaching. At the foundation, all of it is the same.

We believe that to dance Argentine tango well, a dancer must have an open mind, and an open heart. Until they have both, a dancer will always be limiting themselves in some way.

Tango is a simple dance. Mastering a few things in a person&#8217;s posture and movement gives a tango dancer access to all that tango is. While providing a lifetime of challenges and growth.

The path to the fundamentals of tango movement and dance is the same regardless of a persons role in the dance. The roles of leader and follower carry too much weight, there should instead only be tango dancer, embodying both initiator and responder.

The musculoskeletal system, posture and movement are completely intertwined to create a system which interacts with it&#8217;s self. Movement should not be isolated to a single part of the body, each part should be considered a part of the whole.

&nbsp;